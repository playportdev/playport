stored text
